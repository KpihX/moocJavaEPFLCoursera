
class Banque3 {

	public static void main(String[] args) {
		// ... comme avant

		// Construction des deux clients, notez l'argument booléen:
		// Nouveau (parmètre booléen)
		Client c1 = new Client("Pedro", "Geneve", taux1, 1000.0, taux2, 2000.0, true);
		Client c2 = new Client("Alexandra", "Lausanne", taux1, 3000.0, taux2, 4000.0, false);

		// ... comme avant
	}
}

class Client {

	private String nom;
	private String ville;
	private Compte cpt1, cpt2;
	// Nouvelle variable d'instance
	private boolean masculin;

	// Méthode constructeur, notez le paramètre booléen:
	public Client(String nom, String ville, double taux1, double solde1,
				double taux2, double solde2, boolean masculin) {  // Nouveau
		this.nom = nom;
		this.ville = ville;
		cpt1 = new Compte(taux1, solde1);
		cpt2 = new Compte(taux2, solde2);
		// Nouveau
		this.masculin = masculin;
	}

	public void afficher() {
		// Nouvelle instruction if..else
		if (masculin) {
			System.out.print("   Client ");
		} else {
			System.out.print("   Cliente ");
		}
		System.out.println(nom + " de " + ville);
		System.out.println("      Compte prive:     " +
				cpt1.getSolde() + " francs");
		System.out.println("      Compte d'epargne: " +
				cpt2.getSolde() + " francs");
	}
	// ... comme avant
}

class Compte {
	// ... comme avant
}
