class Fleur {
	private String espece;
	private String couleur;

	public  Fleur(String espece, String couleur)
		{
			this.espece = espece;
			this.couleur = couleur;
			System.out.println(espece + " fraichement cueillie");
		}

  Fleur(Fleur autre)
  {
	  couleur = autre.couleur;
	  System.out.print("Fragile corolle taillée ");
  }
    
	public void eclore() { System.out.println("veiné de " + couleur); }

	public String toString()
		{
			return "qu'un simple souffle" ;
		}

}

class Poeme
{
	public static void main(String[] args)
		{
			Fleur f1 = new Fleur("Violette", "bleu");
			Fleur f2 = new Fleur(f1);
			System.out.print("dans un cristal ");
			f2.eclore();
			System.out.print("ne laissant plus ");
			System.out.println(f1);
			System.out.println(f2);
		}
}
	