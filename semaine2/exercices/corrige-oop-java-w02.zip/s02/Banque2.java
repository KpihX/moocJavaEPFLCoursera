/* Version orientée objets de Banque1. */

class Banque2 {

	public static void main(String[] args) {
		// Variables locales pour les taux d'intérets (afin d'éviter de
		// répéter les mêmes chiffres pour chaque client):
		double taux1 = 0.01;
		double taux2 = 0.02;

		// Construction des deux clients:
		Client c1 = new Client("Pedro", "Genève", taux1, 1000.0, taux2, 2000.0);
		Client c2 = new Client("Alexandra", "Lausanne", taux1, 3000.0, taux2, 4000.0);

		System.out.println("Donnees avant le bouclement des comptes:");
		c1.afficher();
		c2.afficher();

		// Bouclement des comptes des deux clients:
		c1.boucler();
		c2.boucler();

		System.out.println("Donnees apres le bouclement des comptes:");
		c1.afficher();
		c2.afficher();
	}
}

class Client {

	private String nom;
	private String ville;
	private Compte cpt1;
	private Compte cpt2;

	public Client(String nom, String ville, double taux1, double solde1,
				double taux2, double solde2) {
		this.nom = nom;
		this.ville = ville;
		// Construction d'un compte privé:
		cpt1 = new Compte(taux1, solde1);
		// Construction d'un compte d'épargne:
		cpt2 = new Compte(taux2, solde2);
	}

	public void afficher() {
		// Cette méthode affiche les données du client
		System.out.println("   Client " + nom + " de " + ville);
		System.out.println("      Compte prive:     "
					+ cpt1.getSolde() + " francs");
		System.out.println("      Compte d'epargne: "
					+ cpt2.getSolde() + " francs");
	}

	public void boucler() {
		// Cette méthode boucle les deux comptes du client
		cpt1.boucler();
		cpt2.boucler();
	}
}

class Compte {

	private double taux;
	private double solde;

	public Compte(double taux, double solde) {
		this.taux = taux;
		this.solde = solde;
	}

	public double getSolde() {
		return solde;
	}

	public void boucler() {
		// Cette méthode ajoute les intérets au solde
		double interets = taux * solde;
		solde = solde + interets;
	}
}
