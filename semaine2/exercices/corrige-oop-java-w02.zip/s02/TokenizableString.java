import java.util.Scanner;

public class TokenizableString {

	private static Scanner scanner = new Scanner(System.in);
	private String content;
	
	// Index de début et longueur d'une séquence
	private int len;
	private int from;

	
	public TokenizableString(String content) {
		this.content = content;
	}

	/* La fonction suivante teste si le caractère est un séparateur
	 *
	 * Ecrire une fonction présente l'avantage de pouvoir redéfinir facilement 
	 * la notion de séparateur (et éventuellement d'en définir plusieurs)
	 */
	public boolean issep (char c) {
		return (c == ' ');
	}

	public void tokenize() {
		System.out.println("Les mots de \"" + content + "\" sont :");
		from = 0;
		len = 0;
		while (nextToken()) {
			System.out.println("'" + content.substring(from, from+len) + "'");
			from += len;
		}
	}

	/* Il y a *plein* d'autres façons d'écrire cette fonction.
	 *
	 * Je trouve celle-ci élégante.
	 */
	public boolean nextToken(){
		int taille = content.length();

		// saute tous les separateurs à partir de from
		while ((from < taille) && issep(content.charAt(from))) ++from;

		// avance jusqu'au prochain séparateur ou la fin de str
		len = 0;
		for (int i = from; ((i < taille) && !issep(content.charAt(i))); ++len, ++i);

		return (len != 0);
	}

	// ----------------------------------------------------------------------
	public static void main(String[] args){
		String phrase;

		System.out.println("Entrez une chaine : ");
		phrase = scanner.nextLine();

		TokenizableString toToken = new TokenizableString(phrase);
		toToken.tokenize();
	}

}
