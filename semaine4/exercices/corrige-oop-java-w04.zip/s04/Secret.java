import java.util.Random;


class Utils {
	// genere un entier entre 1 et max (compris)
	public static int randomInt(int max) {
		Random r = new Random();
		int val = r.nextInt();
		val = Math.abs(val);
		val = val % max;
		val += 1;
		return val;
	}
}

class Secret {
	
	public static void main(String[]  args){
		String message = "COURAGEFUYONS";
		String cryptage;

		// TEST A CLE
		Code acle1 = new ACle("a cle", "EQUINOXE");
		System.out.print("Avec le code : " );
		acle1.affiche();
		cryptage  = acle1.code(message);
		System.out.print("Codage de " + message + " : ");
		System.out.println(cryptage);
		System.out.print("Decodage de " + cryptage + " : ");
		System.out.println(acle1.decode(cryptage));
		System.out.println("-----------------------------------");
		System.out.println();
		// FIN TEST A CLE

		// TEST A CLE ALEATOIRE
		Code acle2 = new ACleAleatoire(5);
		System.out.print("Avec le code : " );
		acle2.affiche();
		cryptage  = acle2.code(message);
		System.out.print("Codage de " + message + " : ");
		System.out.println(cryptage);
		System.out.print("Decodage de " + cryptage + " : ");
		System.out.println(acle2.decode(cryptage));
		System.out.println("-----------------------------------");
		System.out.println();
		// FIN TEST A CLE ALEATOIRE 

		// TEST CESAR

		Code cesar1 = new Cesar("Cesar", 5);
		System.out.print("Avec le code : " );
		cesar1.affiche();
		cryptage = cesar1.code(message);
		System.out.print("Codage de " + message + " : ");
		System.out.println(cryptage);
		System.out.print("Decodage de " + cryptage + " : ");
		System.out.println(cesar1.decode(cryptage));
		System.out.println("-----------------------------------");
		System.out.println();
		// FIN TEST CESAR

		// TEST CODAGES
		System.out.println("Test CODAGES: ");
		System.out.println("------------- ");
		System.out.println();


		Code[] tab = {   // Decommentez la ligne suivante
				// si vous avez fait la classe Cesar
				new Cesar("cesar", 5),
				new ACle("a cle", "EQUINOXE") ,
				new ACleAleatoire(5),
				new ACleAleatoire(10)};
		
		Codages  codes = new Codages(tab);
		codes.test(message);
		// FIN TEST CODAGE
	}
}


abstract class Code {

	private String nom;

	public Code(String unNom) {
		nom = unNom;
	}

	public abstract String code(String chaine);
	public abstract String decode(String chaine);

	public void affiche() {
		System.out.print(nom);
	}

	public String getNom() {
		return nom;
	}

}


class ACle extends Code {

	private String cle;

	public ACle(String nomCode, String cle)	{
		super(nomCode);
		this.cle = cle;
	}

	public void setCle(String uneCle){
		cle = uneCle;
	}

	public int longueur(){
		return cle.length();
	}

	public String code(String message){
		String codage = "";
		int charMessage;
		int charKey;
		int somme;
		for (int i = 0; i < message.length(); ++i){
			charMessage = message.charAt(i) - 'A' + 1;
			charKey = cle.charAt(i % longueur()) - 'A' + 1;
			somme = (charMessage + charKey) % 26;
			if (somme == 0)
				codage += 'Z';
			else
				codage += (char)('A' + somme - 1);
		}
		return codage;			
	}


	public String decode(String codage)	{
		String message = "";
		int charCodage;
		int charKey;
		int difference;
		for (int i = 0; i < codage.length(); ++i){
			charCodage= codage.charAt(i) - 'A' + 1;
			charKey = cle.charAt(i % longueur()) - 'A' + 1;
			difference = (charCodage - charKey + 26 ) % 26;
			if (difference == 0)
				message += 'Z';
			else
				message += (char)('A' + difference - 1);
		}
		return message;
	}


	public void affiche(){
		super.affiche();
		System.out.println(" avec  " + cle + " comme cle");
	}	
}

class ACleAleatoire extends ACle
{
	private int length;
	private void genereCle(){
		String newKey = "";
		int randomPosition;
		for (int i = 0; i < length; ++i){
			randomPosition = Utils.randomInt(26);
			newKey += (char)(randomPosition + (int)'A' - 1);
		}
		setCle(newKey);
	}


	public ACleAleatoire(int length){
		super("a cle aleatoire","");
		this.length = length;
		genereCle();
	}

}


class Cesar extends ACle {

	private int crans;

	public Cesar(String nomCode, int crans) {
		super(nomCode, "");
		setCle("" + (char)('A' + crans%26 - 1));
		this.crans = crans;
	}


	public void affiche() {
		System.out.println(getNom() + " a " + crans + " crans");
	}

}


class Codages {

	private Code[] codes;

	private Code cleMax() {
		int max = 0;
		int indexMax = -1;
		for (int i = 0; i < codes.length; ++i){
			if (codes[i] instanceof ACleAleatoire){
				int longueur = ((ACleAleatoire)codes[i]).longueur();
				if (longueur > max){
					max = longueur;
					indexMax = i;
				}
			}
		}
		if (indexMax < 0)
			return null;
		else return codes[indexMax];
	}


	public Codages(Code[] someCodes){
		codes = someCodes;
	}


	public void test(String message){
		String coded;
		for (int i = 0; i < codes.length; ++i){
			System.out.print("Avec le code : ");
			codes[i].affiche();
			System.out.print("Codage de " + message + " : " );
			coded = codes[i].code(message);
			System.out.println(coded);
			System.out.print("Decodage de  " + coded + " : " );
			System.out.println(codes[i].decode(coded));
			System.out.println("-----------------------------------");
			System.out.println();
		}
		Code codeMax = cleMax();
		if (codeMax != null) {
			System.out.println("Code aleatoire a cle maximale :");
			codeMax.affiche();
		}

	}
}



