/** Iterface describing the common type of all Expressions */
abstract class Expression {

	public abstract int evaluate();

}

/** Class for plain numbers */
class Number extends Expression {
	private int value;

	public Number(int value) {
		this.value = value;
	}
	
	public int evaluate() {
		return value;
	}
}

/** Abstract Class for Binary Operators */
abstract class BinOp extends Expression {
		
	protected Expression leftOp;
	protected Expression rightOp;
	
	public BinOp(Expression leftOp, Expression rightOp) {
		this.leftOp = leftOp;
		this.rightOp = rightOp;	
	}
	
}

/** Class for sums */
class Sum extends BinOp {
	
	public Sum(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() + rightOp.evaluate();
	}
	
}

/** Class for products */
class Prod extends BinOp {

	public Prod(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() * rightOp.evaluate();
	}
	
}

/** Main class */
class ArithOOP1-bis {

	public static void main(String [] args) {
		//build the expression 3 + 2 * 5
		Expression term = new Sum(
			new Number(3),
			new Prod(
				new Number(2),
				new Number(5)));

		System.out.println(term.evaluate());
	}

}
