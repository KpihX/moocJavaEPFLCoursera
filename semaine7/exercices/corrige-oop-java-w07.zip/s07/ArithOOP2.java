/** Interface that defines the common type for all expressions */
interface Expression {

	public int evaluate();
	public String print();
	
}

/** Class for plain numbers */
class Number implements Expression {
	private int value;

	public Number(int value) {
		this.value = value;
	}
	
	public int evaluate() {
		return value;
	}
	
	public String print() {
		return " " + value + " ";
	}

}

/** Abstract Class for Binary Operators */
abstract class BinOp implements Expression {
		
	protected Expression leftOp;
	protected Expression rightOp;
	
	public BinOp(Expression leftOp, Expression rightOp) {
		this.leftOp = leftOp;
		this.rightOp = rightOp;	
	}
	
}


/** Class for sums */
class Sum extends BinOp {
	
	public Sum(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() + rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "+" + rightOp.print();			
	}
	
}

/** Class for products */
class Prod extends BinOp {
	
	public Prod(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() * rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "*" + rightOp.print();			
	}	
}

/** Class for modulo */
class Modulo extends BinOp {

	public Modulo(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() % rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "%" + rightOp.print();			
	}	
}



/** Main class */
class Arith {

	public static void main(String [] args) {
		//build the expression (3 + 2 * 5) % 7
		Expression term = new Modulo(
			new Sum(
				new Number(3),
				new Prod(
					new Number(2),
					new Number(5))),
			new Number(7));

		System.out.println(term.print() + " evaluates to " + term.evaluate());
	}

}
