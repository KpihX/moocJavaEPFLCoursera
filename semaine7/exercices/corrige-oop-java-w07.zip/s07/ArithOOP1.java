/** Interface donnant un type commun a toutes les expressions*/
interface Expression {

	public int evaluate();

}

/** Une classe pour les nombres */
class Number implements Expression {
	private int value;

	public Number(int value) {
		this.value = value;
	}
	
	public int evaluate() {
		return value;
	}
}

/** Une classe abstraite pour les operateurs binaires */
abstract class BinOp implements Expression {
		
	protected Expression leftOp;
	protected Expression rightOp;
	
	public BinOp(Expression leftOp, Expression rightOp) {
		this.leftOp = leftOp;
		this.rightOp = rightOp;	
	}
	
}

/** Une classe pour les sommes */
class Sum extends BinOp {
	
	public Sum(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() + rightOp.evaluate();
	}
	
}

/** Une classe pour les produits */
class Prod extends BinOp {

	public Prod(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() * rightOp.evaluate();
	}
	
}

/** Classe Principale */
class Arith {

	public static void main(String [] args) {
		//construit l'expression 3 + 2 * 5
		Expression term = new Sum(
			new Number(3),
			new Prod(
				new Number(2),
				new Number(5)));

		System.out.println(term.evaluate());
	}

}
