/** Interface donnant un type commun a toutes les expressions*/
abstract class Expression {

	public abstract int evaluate();
	public abstract String print();
	
}

/** Une classe pour les nombres */
class Number extends Expression {
	private int value;

	public Number(int value) {
		this.value = value;
	}
	
	public int evaluate() {
		return value;
	}
	
	public String print() {
		return " " + value + " ";
	}

}

/** Une classe abstraite pour les operateurs binaires */
abstract class BinOp extends Expression {
		
	protected Expression leftOp;
	protected Expression rightOp;
	
	public BinOp(Expression leftOp, Expression rightOp) {
		this.leftOp = leftOp;
		this.rightOp = rightOp;	
	}
	
}


/** Une classe pour les sommes */
class Sum extends BinOp {
	
	public Sum(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() + rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "+" + rightOp.print();			
	}
	
}

/** Une classe pour les produits */
class Prod extends BinOp {
	
	public Prod(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() * rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "*" + rightOp.print();			
	}	
}

/** Une classe pour le modulo */
class Modulo extends BinOp {

	public Modulo(Expression leftOp, Expression rightOp) {
		super(leftOp, rightOp);
	}

	public int evaluate() {
		return leftOp.evaluate() % rightOp.evaluate();
	}
	
	public String print() {
		return leftOp.print() + "%" + rightOp.print();			
	}	
}



/** Classe principale */
class ArithOOP2Bis {

	public static void main(String [] args) {
		//construit l'expression (3 + 2 * 5) % 7
		Expression term = new Modulo(
			new Sum(
				new Number(3),
				new Prod(
					new Number(2),
					new Number(5))),
			new Number(7));

		System.out.println(term.print() + " s'evalue " + term.evaluate());
	}

}
