// Hierarchie de classe pour les items
// (i.e. les choses que l'on peut mettre dans un carton)

abstract class Item {
	public abstract void print();
	public abstract boolean find(String ItemName);
}

// Un objet simple est un Item
class SimpleItem extends Item {

	private String name;

	public SimpleItem(String aName) {
		name = aName;
	}

	public void print(){
		System.out.println(name);
	}

	public boolean find(String ItemName){
		return (name.equals(ItemName));
	}

}

// et un carton est aussi un Item
// ici la subtilit'e est dans la structure r'ecursive de
// la classe Box: une Box est un Item et contient des Items
class Box extends Item {

	private Item content[];
	private int nbItems;
	private int number;

	public Box(int size, int aNumber){
		content = new Item[size];
		nbItems = -1;
		number = aNumber;
	}

	public void addItem(Item item){
		if (nbItems < content.length - 1) {
			++nbItems;
			content[nbItems] = item;
		}
	}

	public int getNumber(){
		return number;
	}

	public void print(){
		for (int i = 0; i <= nbItems; ++i) {
			content[i].print();
		}
	}

	public boolean find (String ItemName){
		for (int i = 0; i <= nbItems; ++i) {
			if (content[i].find(ItemName))
				return true;
		}
		return false;
	}

}

// Le demenagement est un ensemble de cartons
public class Demenagement{

	private Box[] boxes;
	private int index;

	public Demenagement(int boxNumber){
		boxes = new Box[boxNumber];
		index = -1;
	}

	public void addBox(Box box){
		if (index < boxes.length - 1) {
			++ index;
			boxes[index] = box;
		}
	}

	public void print(){
		System.out.println("Les objets de mon demenagement sont :");
		for (int i = 0; i <= index; ++i) {
			boxes[i].print();
		}
	}

	// la nature r'ecursive des cartons
	// fait qu'une recherche r'ecursive est
	// la solution la plus naturelle
	public int find(String itemName){
		for (int i = 0; i <= index; ++i) {
			if (boxes[i].find(itemName))
				return boxes[i].getNumber();
		}
		return -1;
	}

	public static void main(String[] args) {
		//On cr'ee un d'em'enagement constitu'e de 2 cartons principaux
		Demenagement demenagement = new Demenagement(2);
		
		//On cr'ee et remplis ensuite 3 cartons
		Box box1 = new Box(1,1);
		box1.addItem(new SimpleItem("ciseaux"));
		Box box2 = new Box(1,2);
		box2.addItem(new SimpleItem("livre"));
		Box box3 = new Box(2,3);
		box3.addItem(new SimpleItem("boussole"));
		
		//On ajoute ensuite un autre carton a` ce dernier qui contient un objet "'echarpe"
		Box box4 = new Box(1,4);
		box4.addItem(new SimpleItem("echarpe"));
		box3.addItem(box4);

		//On ajoute les trois cartons au premier carton du d'em'enagement
		Box box5 = new Box(3,5);
		box5.addItem(box1);
		box5.addItem(box2);
		box5.addItem(box3);
		
		//On ajoute un carton contenant 3 objets au d'em'enagement
		Box box6 = new Box(3,6);
		box6.addItem(new SimpleItem("crayons"));
		box6.addItem(new SimpleItem("stylos"));
		box6.addItem(new SimpleItem("gomme"));
		

		//On ajoute les deux cartons les plus externes au d'em'enagement
		demenagement.addBox(box5);
		demenagement.addBox(box6);

		//On imprime tout le contenu du d'em'enagement
		demenagement.print();

		//On imprime le num'ero du carton le plus externe contenant l'objet "'echarpe"
		System.out.println("L''echarpe est dans le carton num'ero " + demenagement.find("echarpe"));
	}
}


