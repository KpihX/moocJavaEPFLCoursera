//Exemple d'utilisation. 
class EmployeMain {

  public static void main(String[] args) {
    Gestion gestion = new Gestion();

    // On cr'ee un employ'e Temporaire "T1", et on l'embauche
    Temporaire t1 = new Temporaire("T1", 21, 20);
    gestion.embaucher(t1);
    gestion.afficherEmploye("T1");

    // On le mute dans la categorie Permanent
    gestion.muter(new Permanent(t1, 0, false, 110, 4200));
    gestion.afficherEmploye("T1");

    System.out.println();

    // On cr'ee un employ'e temporaire "P3", et on l'embauche
    Permanent p3 = new Permanent("P3", 1, true, 100, 2000, 20);
    gestion.embaucher(p3);
    gestion.afficherEmploye("P3");

    // On le mute dans la categoire de Temporaire
    gestion.muter(new Temporaire(p3, 20));
    gestion.afficherEmploye("P3");
  }
}


/**
 * Contient la liste des employ'es, et les m'ethodes pour les g'erer, 
 * avec les m'ethodes embaucher, licencier et afficherEmployer
 * Pour muter un employ'e, il faut cr'eer le nouvel employ'e en utilisant 
 * le constructeur a` ce effet, et le notifier a` Gestion en appelant la 
 * m'ethode muter.
 * Par exemple:
 * Temporaire e = new Temporaire("T1", 20, 22);
 * gestion.embaucher(e);
 * Permanent eMute = new Permanent(e,0,false,1000,1200);
 * gestion.muter(eMute);
 */
class Gestion {
  private Employe [] employes = new Employe [100];
  final static int nombreJoursMois = 20;

  /**
   * Ajoute l'employ'e dans <employes>
   */
  public void embaucher(Employe employe) {
    // On ne peut avoir qu'un seul employ'e avec le meme nom
    if (getIndexOfEmploye(employe.getNom()) != -1) {
      System.out.println("Il y a d'eja` un employ'e nomm'e " + employe.getNom() 
			 + " dans gestion");
      return;
    }

    // Trouver le premier emplacement vide (i.e. null) dans le tableau
    for (int i = 0; i < employes.length; i++) {
      if (employes [i] == null) {
          employes [i] = employe;
          return;
      }
    }

    System.out.println("Votre 'equipe est au complet");
  }

  /**
   * Cette m'ethode utilitaire retourne l'index d'un employ'e dans le tableau
   * @param nom nom de l'employ'e a` trouver
   * @return l'index de l'employ'e, ou -1 s'il n'est pas dans la liste
   */
  private int getIndexOfEmploye(String nom) {
    for (int i = 0; i < employes.length; i++) {
      if ((employes [i] != null) && (employes [i].getNom().equals(nom))) {
          return i;
      }
    }
    return -1;
  }

  /**
   * Licencie l'employ'e de Gestion
   */
  public void licencier(Employe employe) {
    int index = getIndexOfEmploye(employe.getNom());
    if (index == -1) {
      System.out.println("Il n'y a pas d'employ'e nomm'e " + employe.getNom());
      return;
    }

    employes[index] = null;
  }

  /**
   * Retourne l'employ'e connaissant son nom
   */
  public Employe getEmploye(String nom) {
    int index = getIndexOfEmploye(nom);
    if (index == -1) {
      System.out.println("Il n'y a pas d'employ'e nomm'e " + nom);
      return null;
    }

    return employes[index];
  }

  /**
   * Affiche l'employ'e
   */
  public void afficherEmploye(String nom) {
    getEmploye(nom).affiche();
  }

  /**
   * employeNouvelleCategorie doit etre initialis'ee avec le nouveau type 
   * d'Employe en utilisant son constructeur qui prend l'ancien employ'e 
   *comme parametre. Regardez le commentaire de la classe Gestion.
   */
  public void muter(Employe employeNouvelleCategorie) {
    int index = getIndexOfEmploye(employeNouvelleCategorie.getNom());

    if (index == -1) {
      System.out.println("Il n'y a pas d'employ'e nomm'e " + 
			 employeNouvelleCategorie.getNom());
    }

    employes[index] = employeNouvelleCategorie;
  }
}

/**
 * La classe de base pour tous les types d'employ'es
 */
abstract class Employe {

  // Nom de l'employ'e
  // Son statut est donn'e par le type de classe
  private String nom;

  // Constructeur de base
  public Employe(String nom) {
    this.nom = nom;
  }

  /**
   * Chaque type d'employ'e doit retourner le salaire cumul'e en CHF
   */
  abstract public double salaireCumule();

  /**
   * Change le nom d'un employ'e
   */
  public void setNom(String nom) {
    this.nom = nom;
  }

  /**
   * Retourne le nom d'un employ'e
   */
  public String getNom() {
    return nom;
  }

  public void affiche() {
    System.out.println(" nom de l'employ'e=" + nom);
    System.out.println(" salaire cumul'e=" + salaireCumule());
  }
}

/**
 * C'est un type d'employ'e qui a un salaire mensuel fixe
 */
class Permanent extends Employe {

  private int nombreEnfants;
  private boolean marie;

  private double salaireMensuel;
  private double primeParEnfantParMois;

  private int joursCumules;

  /**
   * Constructeur de base
   */
  public Permanent(String nom, int nombreEnfants, boolean marie, 
		   double primeParEnfantParMois, double salaireMensuel, 
		   int joursCumules) {
    super(nom);
    this.nombreEnfants = nombreEnfants;
    this.marie = marie;
    this.primeParEnfantParMois = primeParEnfantParMois;
    this.salaireMensuel = salaireMensuel;
    this.joursCumules = joursCumules;
  }

  
  /**
   * Constructeur utilis'e pour la mutation. On doit lui fournir l'employ'e 
   * avant la mutation, ie, "ancien".
   * On prend son nom et on utilise son salaireCumul'e pour le convertir de 
   * façon a` etre compatible avec sa nouvelle categorie
   */
  public Permanent(Employe ancien, int nombreEnfants, boolean marie, 
		   double primeParEnfantParMois, double salaireMensuel) {
    // this permet ici d'invoquer le constructeur de la classe
    // dont la liste de parame`tres correspond a` celle fournie (ici ce sera
    // le constructeur pr'ec'edent.
    // C'est une nouvelle instruction que vous d'ecouvrez ici.
    // Vous pouvez en fait vous en passer, mais ceci impliquerait de dupliquer 
    // toutes les lignes de code li'ees a` l'initialisation des attributs
    // nombreEnfant, marie,primeParEnfantParMois et salaireMensuel.
    this(ancien.getNom(), nombreEnfants, marie, primeParEnfantParMois, 
	 salaireMensuel,0);
    joursCumules = (int) (ancien.salaireCumule() * 
			  (Gestion.nombreJoursMois / getGain()));
  }

  /**
   * Retourne le salaire cumul'e en CHF
   */
  public double salaireCumule() {
    return (getGain() * joursCumules / (double) Gestion.nombreJoursMois);
  }

  /**
   * Retourne le salaire mensuel fixe (contenant aussi les primes)
   */
  private double getGain() {
    double gain = salaireMensuel;
    if (marie && nombreEnfants > 0) {
      gain += primeParEnfantParMois * nombreEnfants;
    }
    return gain;
  }

  public void affiche() {
    super.affiche();
    System.out.println(" nombre d'enfants=" + nombreEnfants);
    System.out.println(" mari'e=" + marie);
    System.out.println(" salaire mensuel=" + salaireMensuel);
    System.out.println(" prime/enfant/mois=" + primeParEnfantParMois);
  }

  public void setJoursCumules(int joursCumules) {
    this.joursCumules = joursCumules;
  }

  public int getJoursCumules() {
    return joursCumules;
  }

  public void setNombreEnfants(int nombreEnfants) {
    this.nombreEnfants = nombreEnfants;
  }

  public int getNombreEnfants() {
    return nombreEnfants;
  }

  public void setMarie(boolean marie) {
    this.marie = marie;
  }

  public boolean estMarie() {
    return marie;
  }

  public void setSalaireMensuel(double salaireMensuel) {
    this.salaireMensuel = salaireMensuel;
  }

  public double getSalaireMensuel() {
    return salaireMensuel;
  }

  public void setPrimeParEnfantParMois(double primerParEnfantParMois) {
    if(marie) {
      this.primeParEnfantParMois = primerParEnfantParMois;
    } else {
      this.primeParEnfantParMois = 0;
    }
  }

  public double getPrimerParEnfantParMois() {
    return primeParEnfantParMois;
  }

}


/**
 * C'est un type d'employ'e pay'e a` l'heure
 */
class Temporaire extends Employe {

  private double salaireHoraire;

  private int heuresCumulees;

  /**
   * Constructeur de base
   */
  public Temporaire(String nom, double salaireHoraire, int heuresCumulees) {
    super(nom);
    this.salaireHoraire = salaireHoraire;
    this.heuresCumulees = heuresCumulees;
  }

  /**
   * Constructeur de base
   */
  public Temporaire(String nom, double salaireHoraire) {
    this(nom, salaireHoraire, 0);
  }

  /**
   * Constructeur utilis'e par la mutation. On doit lui fournir l'employ'e 
   * avant la mutation, ie, "ancien".
   * On prend son nom et on utilise son salaireCumul'e pour le convertir de 
   * façon a` etre compatible avec sa nouvelle categorie
   */
  public Temporaire(Employe ancien, double salaireHoraire) {
    // si vous ne voyez pas ce qe veut dire ce this
    // retourner au commentaire associ'e au constructeur
    // de la classe Permanent.
    this(ancien.getNom(), salaireHoraire);
    muterDonnees(ancien);
  }

  /**
   * Cette m'ethode effectue la mutation depuis une autre cat'egorie d'employ'es
   * en mettant a` jour l'attribut <heuresCumulees> en fonction du 
   * <salaireCumule> de l'Employe.
   * @param ancien	instance de l'ancien type de l'employe
   */
  protected void muterDonnees(Employe ancien) {
    setHeuresCumulees((int) (ancien.salaireCumule() / salaireHoraire));
  }

  /**
   * Retourne le salaire cumul'e en CHF
   */
  public double salaireCumule() {
    return heuresCumulees * salaireHoraire;
  }

  public void affiche() {
    super.affiche();
    System.out.println(" salaire horaire=" + salaireHoraire);
    System.out.println(" heures cumul'ees=" + heuresCumulees);
  }

  public void setHeuresCumulees(int heuresCumulees) {
    this.heuresCumulees = heuresCumulees;
  }

  public int getHeuresCumulees() {
    return heuresCumulees;
  }

  public void setSalaireHoraire(int salaireHoraire) {
    this.salaireHoraire = salaireHoraire;
  }

  public double getSalaireHoraire() {
    return salaireHoraire;
  }
}


class Vendeur extends Temporaire {

  private double volumeVentes;
  private double pourcentageCommissionVentes;

  /**
   * Constructeur de base
   */
  public Vendeur(String nom, double salaireHoraire, double pourcentageCommissionVentes, int heuresCumulees, int volumeVentes) { /**/
    super(nom, salaireHoraire, heuresCumulees);
    this.pourcentageCommissionVentes = pourcentageCommissionVentes;
    this.volumeVentes = volumeVentes;
  }

  /**
   * Constructeur de base
   */
  public Vendeur(String nom, double salaireHoraire, double pourcentageCommissionVentes) {
    this(nom, salaireHoraire, pourcentageCommissionVentes, 0, 0);
  }

  /**
   * Constructeur utilis'e par la mutation. On doit lui fournir l'employ'e 
   * avant la mutation, ie, "ancien".
   * On prend son nom et on utilise son salaireCumul'e pour le convertir 
   * de façon a` etre compatible avec sa nouvelle categorie
   */
  public Vendeur(Employe ancien, double salaireHoraire, double pourcentageCommissionVentes) {
    this(ancien.getNom(), salaireHoraire, pourcentageCommissionVentes, 0, 0);
    muterDonnees(ancien);
  }

  /**
   * Retourne le salaire cumul'e en CHF
   */
  public double salaireCumule() {
    return super.salaireCumule() + volumeVentes * pourcentageCommissionVentes;
  }

  public void affiche() {
    super.affiche();
    System.out.println( " volume de ventes=" + volumeVentes);
    System.out.println(" commission sur la vente=" + 
		       pourcentageCommissionVentes);
  }

  public void setVolumeVentes(double volumeVentes) {
    this.volumeVentes = volumeVentes;
  }

  public double getVolumeVentes() {
    return volumeVentes;
  }

  public void setPourcentageCommissionVentes(double pourcentageCommissionVentes) {
    this.pourcentageCommissionVentes = pourcentageCommissionVentes;
  }

  public double getPourcentageCommissionVentes() {
    return pourcentageCommissionVentes;
  }
}
