import java.util.Scanner;

class RLE {

	private static Scanner scanner = new Scanner(System.in);

	private final static char FLAG = '#';

	public static void main(String[] args) {
		
		System.out.println("Entrez les données à comprimer : ");
		String dta = scanner.nextLine();
		String rle = RLEAlgorithm.compress(dta, FLAG);
		System.out.println("Forme compressée:   " + rle + "\n[ratio = " + rle.length()*100.0/dta.length() + "%]");
		String dcp = "";
		try {
			dcp = RLEAlgorithm.decompresse(rle, FLAG);
		} catch (RLEException e) {
			e.printStackTrace();
		}
		if (!dcp.equals(dta)) {
			System.out.println("Erreur - données corrompues:" + dcp);
		} else {
			System.out.println("décompression ok!");
		}

		// teste la decompression
		System.out.println("Entrez les données à décompresser : ");
		dta = scanner.nextLine();
		try {
			dcp = RLEAlgorithm.decompresse(dta, FLAG);
			System.out.println("décompressé : " + dcp);
		}
		catch (RLEException exception) {
			System.out.println("Erreur de décompression : " + exception.getMessage() + "\n");
			System.out.println("décodé à ce stade : " + exception.getDecoded() + "\n");
			System.out.println("non décodé        : " + exception.getRemaining());
		}
	}
}

class RLEException extends Exception {
	private String decoded;
	private String remaining;
	
	public RLEException(String message, String decoded, String remaining) {
		super(message);
		this.decoded = decoded;
		this.remaining = remaining;
	}
	
	public String getRemaining() {
		return remaining;
	}
	
	public String getDecoded() {
		return decoded;
	}
	
}

class RLEAlgorithm {

	public static String compress(String data, char flag) {
		char currentChar;         // caractère extrait
		int  repetitionCount;         // nombre de répétitions à produire
		int currentIndex = 0; // position dans la chaine à décompresser
		String result = "";     // chaine compressée

		while (currentIndex < data.length()) {
			repetitionCount = 1;
			if ((currentChar = data.charAt(currentIndex)) == flag) {
				++currentIndex;
				result += currentChar;
				result += 0;
			} else {
				while ((++currentIndex < data.length()) && (repetitionCount < 9) && (data.charAt(currentIndex) == currentChar)) {
					repetitionCount++;
				}
				if (repetitionCount >= 3) {
					result += currentChar;
					result += flag;
					result += repetitionCount;
				} else { 
					while (repetitionCount-- > 0) {
						result += currentChar;
					}
				}
			}
		}
		return result;
	}

	public static String decompresse(String rledata, char flag) throws RLEException	{
		char currentChar;         // caractère extrait
		int  repetitionCount;         // nombre de répétitions à produire
		int currentIndex; // position dans la chaine à décompresser
		String out = "";     // chaine décompressée

		for (currentIndex = 0; currentIndex < rledata.length(); currentIndex++) {
			currentChar = rledata.charAt(currentIndex);
			if ((currentIndex+1 < rledata.length()) 
					&& (rledata.charAt(currentIndex+1) == flag)) {
				// flag en p+1 détecté ?
				currentIndex += 2;
				if (currentIndex >= rledata.length()) {
					// erreur : on devrait avoir qqchode derrière le FLAG
					String msg = "Flag " + flag + " sans rien derrière";
					String decode = out + currentChar;
					String remaining = flag + rledata.substring(currentIndex);
					throw new RLEException(msg, decode, remaining);

				} else if ((rledata.charAt(currentIndex) >= '0') 
						&& (rledata.charAt(currentIndex) <= '9')) { 
					repetitionCount = Integer.parseInt("" + rledata.charAt(currentIndex)); // on récupère l
					if (repetitionCount >= 1) {
						while (repetitionCount-- > 0) {
							out += currentChar; // décompression des l x c
						}
					} else {
						// l=0 -> le flag était dans les données
						out += currentChar;
						out += flag;
					}
				} else {
					// erreur : ce qui suit le FLAG n'est pas correct
					String msg = "Caractère " + rledata.charAt(currentIndex) + " incorrect après le flag " + flag;
					String decoded = out + currentChar;
					String remaining = flag + rledata.substring(currentIndex);
					throw new RLEException(msg,decoded,remaining);
				}
			} else {
				// caractère seul
				out += currentChar;
				if (currentChar == flag) {
					++currentIndex; // saute le 0 dans le cas d'un flags au début ("#0")
				}
			}
		}
		return out;
	}

}
/*
 * Question subsidiaire : 
 *
 * - pour coder de grandes séquences consécutives, on peut par exemple utiliser
 *   les valeurs 'spéciales' de l (dans notre cas 0, 1 et 2, puisque les 
 *   chaînes de longueurs inférieur à 3 ne sont pas compressées. Nous utilisons
 *   déjà le 0 pour le flag seul) pour indiquer une extension du codage du 
 *   nombre de répétitions. Par exemple :
 *     1) l = 1 -> codage sur par exemple 2 digits => on passe à une longueur 
 *                 max de 99 caractères
 *     2) l = 2 -> codage sur par exemple 3 digits => l max = 999
 *   et on peut continuer le raisonnement :
 *     avec l = 1, la longueur 'minimale' codée de manière étendue devrait être
 *     10 (sinon on code comme avant).
 *       1b) on peut donc encoder l avec un décalage de 10 -> l code donc de 10
 *           (#100) à 109 (#199), lmax devient donc 109 au lieu de 99.
 *       1c) on peut utiliser à nouveau tout ou une partie de ces valeurs pour 
 *           prolonger l'encodage étendu...
 *
 *       Exemple: on doit coder 105 caractères 'c' consécutifs:
 *          cas 1:   c#199c#6    (1->99 puis 105-99=6 codés en normal)
 *          cas 2:   c#2105      (2->105 sur 3 digits)
 *          cas 1b:  c#195       (1->95+biais = 95+10 = 105)
 *     
 * - On peut utiliser la même technique pour coder des répétitions du flag ;
 *   dans ce cas, on peut utiliser par exemple la valeur spéciale '2' pour 
 *   indiquer que le flag est effectivement compressé, et le nombre de 
 *   répétitions est encodé sur le prochain caractère.
 *
 *   Exemple:
 *             à compresser: aa#####bb
 *                        -> aa#25bb
 *
 *   On constate que dans ce cas, il devient intéressant de coder des 
 *   répétitions de 2 flags déjà (3 caractères (#22) contre 4 avec la version 
 *   '#0' (#0#0))
 *
 * En résumé, il est possible d'utiliser les valeurs 'impossibles' de l pour 
 * indiquer des cas spéciaux, ou encore encoder les valeurs avec un certain 
 * biais. On étend ainsi légèrement la plage de valeurs représentable, pour un 
 * très faible surcoût de complexité.
 * À ce propos, l'un des avantage de la compression RLE est justement sa 
 * faible complexité algorithmique (i.e. temps consommé pour réaliser la 
 * compression).
 */