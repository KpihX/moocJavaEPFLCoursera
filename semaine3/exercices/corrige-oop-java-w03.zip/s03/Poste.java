/* Classe pour représenter le courrier
 */

class Courrier {
	// retourne le montant n'ecessaire pour affranchir le courrier
	// en mode d'exp'edition normal
	
	// on va faire une chose tre`s vilaine parcequ'on ne connait pas les
	// m'ethodes abstraites : on va lui donner un corps arbitrairement
	// d'efini (car on ne sait pas la d'efinir proprement
	// a` ce niveau de la hi'erarchie
	public double affranchirNormal(){return 0;};
	// la bonne solution consiste a` d'eclarer cette m'ethode comme suit:
	// abstract private double affranchirNormal();
	// lorsque vous aurez vu les cours de la semaine prochaine, expliquez pourquoi...
	
	// les attributs (communs aux lettres et colis):
	private double poids;
	private boolean express;
	private String adresse;

	// un constructeur possible pour la classe
	public Courrier(double poids, boolean express, String adresse) {
		this.poids = poids;
		this.express = express;
		this.adresse = adresse;
	}

		// un getter pour le poids (car utile dans les sous-classe)
	public double getPoids() {
		return poids;
	}

	// retourne le montant n'ecessaire pour affranchir le courrier.
	// elle appelle affranchirNormal et retourne le double de ce montant
	// si le mode d'exp'edition est  express ('eviter la duplication du code
	// qui double le montant dans les m'ethodes affranchir-normal
	// des sous-classes)
	public double affranchir() {
		if (! valide())
		{
			return 0;
		}
		else
		{
			double total = affranchirNormal();
			if (express) {
				total *= 2;
			}
			return total;
		}
	}

	// un courrier est invalide si l'adresse de destination est vide
	// methode utilis'ee par Boite::affranchir et
	// Boite::courriersInvalides
	public boolean valide() {
		return adresse.length() > 0;
	}
	
	@Override
	public String toString() {
		String s = "";
		if (!valide())
		{
			s+= "(Courrier  invalide)\n";
		}
		s+= "	Poids : " + poids + " grammes\n";
		s+= "	Express : " + (express ? "oui" : "non") + "\n";
		s+= "	Destination : " + adresse + "\n";
		s+= "	Prix : " + affranchir() + " CHF\n";
		return s;
	}

}

/* Une classe pour repr'esenter les lettres
 */

class Lettre extends Courrier {

	//attributs sp'ecifiques aux lettres:
	private String format = "";

	public Lettre(double poids, boolean express, String adresse, String format){
		super(poids, express, adresse);
		this.format = format;
	}

	// red'efinit affranchirNormal()
	public double affranchirNormal() {
		double montant = 0;
		if (format.equals("A4")){
			montant = 2.0;
		} else {
			montant = 3.5;
		}
		montant += getPoids()/1000.0;
		return montant;
	}

	// inutile de red'efinir la méthode valide() pour les  lettres
	
	@Override
	public String toString() {
		String s = "Lettre\n";
		s += super.toString();
		s += "	Format : " + format + "\n";
		return s;
	}

}
/* Une classe pour repr'esenter les publicit'es
 */

class Publicite extends Courrier {

	public Publicite(double poids, boolean express, String adresse){
		super(poids, express, adresse);
	}

	// redéfinit affranchirNormal()
	public double affranchirNormal() {
		return getPoids()/1000.0 * 5.0;
	}


	// inutile de red'efinir la méthode valide() pour les  publicités

	@Override
	public String toString() {
		String s = "Publicité\n";
		s += super.toString();
		return s;
	}
	
}

/* Une classe pour repr'esenter les colis
 */
class Colis extends Courrier {

	//attributs sp'ecifiques aux colis:
	private double volume;

	public Colis(double poids, boolean express, String adresse, double volume) {
		super(poids, express, adresse);
		this.volume = volume;
	}

	// redéfinit affranchirNormal();
	public double affranchirNormal() {
		// affranchit les colis selon une formule pr'ecise
		return 0.25 * volume + getPoids()/1000.0;
	}

	// ici il faut red'efinir  (sp'ecialiser) la re`gle de validit'e des colis
	// un colis est invalide s' il  a une mauvaise adresse
	//ou depasse un certain volume
	public boolean valide(){
		return (super.valide() && volume <= 50);
	}
	
	@Override
	public String toString() {
		String s = "Colis\n";
		s += super.toString();
		s += "	Volume : " + volume + " litres\n";
		return s;
	}


}

/* 	 Une classe pour repr'esenter la boite aux lettre
 */

class Boite {

	private Courrier[] contenu;
	private int index;

	// constructeur
	public Boite(int max) {
		contenu = new Courrier[max];
		index = 0;
	}

	// la méthode demand'ee
	public double affranchir() {
		double montant = 0.0;
		for(int i=0; i < index; ++i){
			Courrier c = contenu[i];
			montant += c.affranchir();
		}
		return montant;
	}

	public int size() {
		return index;
	}

	public Courrier getCourrier(int index) {
		if (index < contenu.length)
			return contenu[index];
		else
			return null;
	}

	// autre m'ethode demandée dans l'interface
	// d'utilisation de la classe
	public int courriersInvalides() {
		int count = 0;
		for (int i = 0; i < index; i++) {
			if (!contenu[i].valide())
				count++;
		}
		return count;
	}

	// difficile de fonctionner sans 
	public void ajouterCourrier(Courrier  unCourrier) {
		if (index < contenu.length){
			contenu[index] = unCourrier;
			index++;
		} else {
			System.out.println("Impossible d'ajouter un nouveau courrier. Boite pleine !");
		}
	}
	
	public void afficher() {
		for (int i = 0; i < index; i++) {
			System.out.println(contenu[i]);
		}
	}
	
}


// PROGRAMME PRINCIPAL (non demandé)
class Poste {

	public static void  main(String args[]) {
		//Cr'eation d'une boite-aux-lettres
		Boite boite = new Boite(30);

		//Creation de divers courriers/colis..
		Lettre lettre1 = new Lettre(200, true, "Chemin des Acacias 28, 1009 Pully", "A3");
		Lettre lettre2 = new Lettre(800, false, "", "A4"); // invalide

		Publicite pub1 = new Publicite(1500, true, "Les Moilles  13A, 1913 Saillon");
		Publicite pub2 = new Publicite(3000, false, ""); // invalide

		Colis colis1 = new Colis(5000, true, "Grand rue 18, 1950 Sion", 30);
		Colis colis2 = new Colis(3000, true, "Chemin des fleurs 48, 2800 Delemont", 70); //Colis invalide !

		boite.ajouterCourrier(lettre1);
		boite.ajouterCourrier(lettre2);
		boite.ajouterCourrier(pub1);
		boite.ajouterCourrier(pub2);
		boite.ajouterCourrier(colis1);
		boite.ajouterCourrier(colis2);


		System.out.println("Le montant total d'affranchissement est de " +
						   boite.affranchir());
		boite.afficher();
		
		System.out.println("La boite contient " + boite.courriersInvalides()
						   + " courriers invalides");
	}
}
